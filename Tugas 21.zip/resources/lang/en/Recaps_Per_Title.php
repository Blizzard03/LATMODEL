<?php
return 
[
    'title'=>'Recaps Per Title',
    'table_data'=>
    [
        'Judul_Buku'=> 'Book Title',
        'Penulis'->'Author',
        'Lama_Pinjam'=>'Borrowing time'
        'Keterlambatan'=>'Lateness',
        'Denda'=>'Loans'
]
]

?>

