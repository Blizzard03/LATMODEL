<?php
return 
[
	'title' => 'Librarians Table Data',
	'display' => [
		'Id' =>'Id',
		'NIP'    => 'NIP',
				'Nama'  => 'Libarian Name',
				'Golongan' => 'Rank',
				'tombol1'  => 'Add Libarian',
            'tombol2'  => 'Edit Data',
            'tombol3'  => 'Delete Data',
			'edit' => 'Edit',
            'hapus'=> 'Delete',
],
'confirmation' => 'Are You Sure This Data Will Be Deleted Permanent?'
];?>
