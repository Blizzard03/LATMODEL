<?php
return 
[
	'title' => 'Insert Data Book',
	'input' => ['judul'    => 'Book Title',
				'penulis'  => 'Author',
				'penerbit' => 'Publisher',
				'kategori' => 'Category',
				'pilihan_kategori' => 
				  ['sains' => 'Science',
				   'fiksi' => 'Fictions',
				  ],
				'harga'    => 'Book Price',
				'tombol1'  => 'Save',
				'tombol2'  => 'Cancel',
			   ]
];
?>