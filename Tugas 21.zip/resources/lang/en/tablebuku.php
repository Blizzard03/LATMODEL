<?php
return
    [
        'title' => 'Book Table Data',
        'display' => [
            'Id'=>'Id',
            'judul'    => 'Book Title',
            'penulis'  => 'Writer',
            'penerbit' => 'Publisher',
            'kategori' => 'Category',
            'harga'    => 'Book Price',
            'edit' => 'Edit',
            'hapus'=> 'Delete',
            'tombol1'  => 'Add Book',
            'tombol2'  => 'Edit Data',
            'tombol3'  => 'Delete Data',
            'pilihan_kategori' =>
            [
                'sains' => 'Sciences',
                'fiksi' => 'Fictions',
            ]
        ],
        'confirmation' => 'Are You Sure This Data Will Be Deleted Permanent?'
    ];
