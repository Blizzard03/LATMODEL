<?php
return
    [
        'title1' => 'Books Table Data',
        'title2' => 'Members Table Data',
        'title3' => 'Librarians Table Data',
        'title4' => 'Loans Report',
        'title5' => 'Fines Report',
        'title6' => 'Recaps Per Title',
        'footer1'=> 'Juanda University Library',
        'footer2'=> 'Dago 96 Street Bandung West Java'
    ];?>
