<?php
return 
[
	'title' => 'Add Data Librarian',
	'input' => ['NIP'    => 'NIP',
				'Nama'  => 'Libarian Name',
				'Golongan' => 'Rank',
				'tombol1'  => 'Save',
				'tombol2'  => 'Batal',
			   ]
];
?>