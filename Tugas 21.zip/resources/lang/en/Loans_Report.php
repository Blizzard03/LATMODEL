<?php
return 
[
    'title'=>'Loans Reports',
    'table_data'=>
    [
        'Id_Peminjaman'=>'Borrower ID',
        'Nama_' => 'Member Name',
        'Judul_Buku'=> 'Book Title',
        'Lama_Pinjam'=>'Borrowing time'
]
]

?>