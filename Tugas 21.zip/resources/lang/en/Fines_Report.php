<?php
return 
[
    'title'=>'Fines Reports',
    'table_data'=>
    [
        'Id_Peminjaman'=>'Borrower ID',
        'Nama_' => 'Member Name',
        'Alamat'=>'Address',
        'Judul_Buku'=> 'Book Title',
        'Penulis'=>'Writer',
        'Lama_Pinjam'=>'Borrowing time',
        'Keterlambatan'=>'Lateness',
        'Denda'=>'Loans'
]
]

?>

