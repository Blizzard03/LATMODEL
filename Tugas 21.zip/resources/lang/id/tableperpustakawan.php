<?php
return
    [
        'title' => 'Tambah  Data Pustakawan',
        'display' => [
            'Id' => 'Id',
            'NIP' => 'NIP',
            'Nama' => 'Nama Perpustakawan',
            'Golongan' => 'Golongan',
            'tombol1' => 'Tambah Perpustakawan',
            'tombol2' => 'Sunting Data',
            'tombol3' => 'Hapus Data',
            'edit' => 'Sunting',
            'hapus' => 'Hapus',
        ],
        'confirmation' => 'Anda Yakin Data Ini Akan Dihapus Permanen?'
    ];
