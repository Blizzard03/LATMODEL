<?php
return 
[
    'title'=>'Laporan Dena',
    'table_data'=>
    [
        'Id_Peminjaman'=>'Id Peminjaman',
        'Nama_' => 'Nama Anggota',
        'Alamat'=>'Alamat',
        'Judul_Buku'=> 'Judul Buku',
        'Penulis'=>'Penulis',
        'Lama_Pinjam'=>'Lama Pinjam',
        'Keterlambatan'=>'Keterlambatan',
        'Denda'=>'Denda'
]
]

?>

