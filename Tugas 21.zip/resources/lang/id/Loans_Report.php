<?php
return 
[
    'title'=>'Laporan Peminjaman',
    'table_data'=>
    [
        'Id_Peminjaman'=>'Id Peminjaman',
        'Nama_' => 'Nama Anggota',
        'Judul_Buku'=> 'Judul Buku',
        'Lama_Pinjam'=>'Lama Pinjam'
]
]

?>