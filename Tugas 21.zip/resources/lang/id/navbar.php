<?php
return
    [
        'title1' => 'Data Tabel Buku',
        'title2' => 'Data Tabel Anggota',
        'title3' => 'Data Tabel Perpustakawan',
        'title4' => 'Laporan Peminjaman',
        'title5' => 'Laporan Denda',
        'title6' => 'Rekap Per Judul',
        'footer1'=> 'Perpustakaan Universitas Juanda',
        'footer2'=> 'Jl. Dago 96 Bandung Jawa Barat'
    ];?>