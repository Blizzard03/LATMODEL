<?php
return
[
'title' => 'Tambah Pustakawan Data',
'tampilkan' => [
'Id' =>'Id',
'NIP' => 'NIP',
'Nama' => 'Nama Libar',
'Golongan' => 'Peringkat',
'tombol1' => 'Tambah Libarian',
             'tombol2' => 'Ubah Data',
             'tombol3' => 'Hapus Data',
'sunting' => 'Ubah',
             'hapus'=> 'Hapus',
],
'confirmation' => 'Anda Yakin Data Ini Akan Dihapus Permanen?'
];
?>