<?php
return 
[
	'title' => 'Tambah Data Anggota',
	'input' => ['NPM'    => 'NPM',
				'Nama_Anggota'  => 'Nama Anggota',
				'Kode_Gender' => 'Gender',
				'pilihan_Kode_Gender' => 
				  ['Laki-Laki' => 'Laki-Laki',
				   'Perempuan' => 'Perempuan',
				  ],
				'Alamat'    => 'Alamat',
				'tombol1'  => 'Simpan',
				'tombol2'  => 'Batal',
			   ]
];
?>