<?php
return 
[
	'title' => 'Tambah Data Perpustakawan',
	'input' => ['NIP'    => 'NIP',
				'Nama'  => 'Nama Perpustakawan',
				'Golongan' => 'Golongan',
				'tombol1'  => 'Simpan',
				'tombol2'  => 'Batal',
			   ]
];
?>