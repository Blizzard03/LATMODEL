<?php
return
    [
        'title' => 'Tabel Data Anggota',
        'tampilkan' => [
            'Id'=>'Id',
            'NPM' => 'NPM',
            'Nama' => 'Nama Anggota',
            'Jenis Kelamin' => 'Jenis Kelamin',
            'Angkatan' => 'Generasi',
            'Jenjang' => 'Pendidikan',
            'Jurusan' => 'Fokus',
            'Alamat' => 'Alamat',
            'sunting' => 'Ubah',
            'hapus'=> 'Hapus',
            'tombol1' => 'Tambah Anggota',
            'tombol2' => 'Ubah Data',
            'tombol3' => 'Hapus Data',
            'pilihan_Kode_Gender' =>
            ['Laki-Laki' => 'Pria',
             'Perempuan' => 'Perempuan',
        ],
            'pilihan_kode_jenjang'=>[
                'Diploma III' => 'Diploma III',
                'Sarjana' =>'Sarjana',
                'Magister'=>'Magister',
            ],
            'pilihan_kode_jurusan'=>[
                'SI'=> 'Sistem Informasi',
                'SK'=>'Sistem Komputer',
                'IT'=>'Informatika'
            ],

        ],
        'confirmation' => 'Anda Yakin Data Ini Akan Dihapus Permanen?'
    ];