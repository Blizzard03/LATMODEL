<?php
return
    [
        'title' => 'Data Table Buku',
        'display' => [
            'Id'=>'Id',
            'judul'    => 'Judul Buku',
            'penulis'  => 'Penulis',
            'penerbit' => 'Penerbit',
            'kategori' => 'Kategori',
            'harga'    => 'Harga Buku',
            'edit' => 'Ubah',
            'hapus'=> 'Hapus',
            'tombol1'  => 'Tambah Buku',
            'tombol2'  => 'Ubah Data',
            'tombol3'  => 'Hapus Data',
            'pilihan_kategori' =>
            [
                'sains' => 'Sains',
                'fiksi' => 'Fiksi',
            ]
        ],
        'confirmation' => 'Yakin Data Ini Akan Di Hapus?'
    ];
