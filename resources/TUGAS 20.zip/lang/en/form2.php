<?php
return 
[
	'title' => 'Insert Data Member',
	'input' => ['NPM'    => 'NPM',
				'Nama_Anggota'  => 'Member Name',
				'Kode_Gender' => 'Gender Code',
				'pilihan_Kode_Gender' => 
				  ['Laki-Laki' => 'Male',
				   'Perempuan' => 'Woman',
				  ],
				'Alamat'    => 'Address',
				'tombol1'  => 'Save',
				'tombol2'  => 'Cancel',
			   ]
];
?>