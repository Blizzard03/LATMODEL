@extends('master')
@section('title', 'Data Perpustakawan')

@section('content')
<div class="container mt-3">
    <h2>{{ __('tablelibaryan.title')}}</h2>
    <p><a href="/createperpustakawan">
            <button class="btn btn-success mb-2">{{ __('tablelibaryan.display.tombol1')}}</button></a></p>

    <table class="table table-bordered table-striped">
        <thead class="table-success">
            <tr>
                <td>{{ __('tablelibaryan.display.Id')}}</td>
                <td>{{ __('tablelibaryan.display.NIP')}}</td>
                <td>{{ __('tablelibaryan.display.Nama')}}</td>
                <td>{{ __('tablelibaryan.display.Golongan')}}</td>
                <td>{{ __('tablelibaryan.display.edit')}}</td>
                <td>{{ __('tablelibaryan.display.hapus')}}</td>
            </tr>
        </thead>

        <tbody>
            @foreach ($data_perpustakawan as $perpustakawan)
            <tr>
                <td>{{$perpustakawan->id}}</td>
                <td>{{$perpustakawan->NIP}}</td>
                <td>{{$perpustakawan->Nama}}</td>
                <td>{{$perpustakawan->Golongan}}</td>
                <td><a href="{{route('ubahperpustakawan', $perpustakawan->id)}}">
                        <button class="btn btn-primary btn-sm">{{ __('tablelibaryan.display.tombol2')}}</button></a></td>
                <td>
                    <form action="{{route('hapusperpustakawan', $perpustakawan->id)}}" method="post">
                        <button class="btn btn-primary btn-sm" onClick="return confirm('Yakin mau dihapus?')">{{ __('tablelibaryan.display.tombol3')}}</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection